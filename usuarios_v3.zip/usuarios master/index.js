//=============================== NOTES ===============================
/*
JSON = JAVASCRIPT OBJECTIVE NOTATION  = {key:value}//

SPA | Single Page Application | (like Gmail)

=== FUNTION STRUCTURE === 

         P //What We'll receive?
Function(Parameter){
}


======== S T A R T =========== SECTION 3: USER MANEGEMENT ======== S T A R T ========= */

// go to the document and query all ("of this condition of this type") and select them
var fields = document.querySelectorAll("#form-user-create [name]");
var user = {};

// add line for each user and set theirs datas.
function addLine(dataUser) {

    //creating the HTML structrue and puting this HTML structure in the ("table-users")  
    document.getElementById("table-users").innerHTML = ` 
        <tr>
            <td><img src="dist/img/user1-128x128.jpg" alt="User Image" class="img-circle img-sm"></td>
            <td>${dataUser.name}</td>
            <td>${dataUser.email}</td>
            <td>${dataUser.admin}</td>
            <td>${dataUser.birth}</td>
            <td>
                <button type="button" class="btn btn-primary btn-xs btn-flat">Editar</button>
                <button type="button" class="btn btn-danger btn-xs btn-flat">Excluir</button>
            </td>
        </tr>
    `;



}

document.getElementById("form-user-create").addEventListener("submit", (event) => {

    event.preventDefault();
    // cancel default behavior

    // for the value of each ${field}, assign it to a ${field} and set its index
    fields.forEach(function(field, index) {

        // logic of gender M and F
        if ((field.name == "gender") && (field.checked === true)) {

            user[field.name] = field.value;

        } else {

            user[field.name] = field.value;
        }
    });

    console.log(user);

    // for the value of each ${field}, assign it to a ${field} and set its index
    fields.forEach(function(field, index) {

        // Logic of the "gender", if the field's name to be "gender" and is checked, so...
        if ((field.name == "gender") && (field.checked === true)) {

            user[field.name] = field.value;

        } else {

            user[field.name] = field.value;
        }
    });


    //"Um OBJETO é uma VARIAVEL que REPRESENTA uma CLASSE"
    //NEW | takes all the properties of the class and gives a variable
    var objectUser = new User(
        user.name,
        user.gender,
        user.birth,
        user.country,
        user.email,
        user.password,
        user.photo,
        user.admin
    );

    addLine(objectUser);

});